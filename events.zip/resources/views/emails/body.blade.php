
<html>
<body>
<h2>{{$title}}</h2>
<p>{{$content}}</p>
</body>
</html>