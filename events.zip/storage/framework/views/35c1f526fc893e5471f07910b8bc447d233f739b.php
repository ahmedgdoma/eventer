<?php $__env->startSection("title"); ?>
    slider
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="box">
        <?php if(session('error_slider')): ?>
            <div class="box-header">
                <div class="callout callout-danger">
                    <h4>error!</h4>
                    <p><?php echo e(session('error_slider')); ?></p>
                </div>
            </div>
        <?php endif; ?>
            <?php if(session('updated_slider')): ?>
                <div class="box-header">
                    <div class="callout callout-success">
                        <h4>congratulations</h4>
                        <p><?php echo e(session('updated_slider')); ?></p>
                    </div>
                </div>
            <?php endif; ?>
    </div>
    <?php echo e(Form::open(['action'=>['MaterialController@update','id'=>0], 'method'=>'PATCH'])); ?>

        <?php foreach($materials as $material): ?>
            <?php if($material->type == 'image'): ?>
                <div class="form-group" style="display: inline-block;margin: 10px">
                    <?php echo e(Form::checkbox($material->id, null, $material->slider, ['class'=>'css-checkbox', 'id'=>$material->id])); ?>

                    <?php echo e(Form::label($material->id,'' ,['class'=>'css-label', 'style'=>'background-image:url('. url('resources/assets/uploads/materials/'.$material->link).");"])); ?>


                </div>
            <?php endif; ?>
        <?php endforeach; ?>

    <div class="box-footer">
        <div class="col-md-4">
            <?php echo Form::submit('submit', ['class' => 'btn btn-primary']);; ?>

        </div>
    </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>