<?php $__env->startSection('title'); ?>
    user profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            <?php echo e($user->name); ?> Profile
        </h1>

        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">users</a></li>
            <li class="active">profile</li>
        </ol>
    </section>
    <Section class="content">
        <div class="row">
            <div class='col-md-6 col-md-offset-3'>
                <!-- Profile Image -->
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <img class="profile-user-img img-responsive img-circle" src="<?php echo e(url('resources\assets\uploads\users\\'). $user->image); ?>" alt="User profile picture">

                        <h3 class="profile-username text-center"><?php echo e($user->first_name); ?></h3>

                        <p class="text-muted text-center"></p>

                        <ul class="list-group list-group-unbordered">
                            <li class="list-group-item">
                                <b>email</b> <a class="pull-right"><?php echo e($user->email); ?></a>
                            </li>
                            <li class="list-group-item">
                                <b>phone</b> <a class="pull-right"><?php echo e($user->phone); ?></a>
                            </li>
                        </ul>

                        <a href="<?php echo e(url('users/'. $user->id . '/edit')); ?>" class="btn btn-primary btn-block"><b>Edit</b></a>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </Section>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>