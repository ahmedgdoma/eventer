
<html>
<body>
<h2><?php echo e($title); ?></h2>
<p><?php echo e($content); ?></p>
</body>
</html>