<?php $__env->startSection("title"); ?>
     edit user
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <section class="content-header">
        <h1>
            edit user
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a class="active">users</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="box">
                    <div class="box-body">
                        <?php echo Form::model($user, ['files'=>'true', 'method'=>'PATCH', 'action' => ['userController@update', 'id'=>$user->id]]); ?>

                        <?php echo e(Form::label('first name')); ?>

                        <?php echo e(Form::text('first_name', null, ['class'=>'form-control', 'placeholder'=>'user first name'])); ?>

                        <?php echo e(Form::label('last name')); ?>

                        <?php echo e(Form::text('last_name', null, ['class'=>'form-control', 'placeholder'=>'user last name'])); ?>

                        <?php echo e(Form::label('image')); ?>

                        <?php echo e(Form::file('image')); ?>

                        <div class="box-footer">
                            <?php echo Form::submit('submit', ['class' => 'btn btn-primary']);; ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>