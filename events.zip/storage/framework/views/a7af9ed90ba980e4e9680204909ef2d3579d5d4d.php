<?php $__env->startSection("title"); ?>
    users
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <section class="content-header">
        <h1>
            users Table
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a class="active">users</a></li>
        </ol>
    </section>
    <section>

    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">

                <div class="box">
                    <?php if(session('error')): ?>
                        <div class="box-header">
                            <div class="callout callout-danger">
                                <h4>error!</h4>
                                <p><?php echo e(session('error')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(session('deleted')): ?>
                        <div class="box-header">
                            <div class="callout callout-info">
                                <h4>congratulations</h4>
                                <p><?php echo e(session('deleted')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                        <?php if(session('added')): ?>
                            <div class="box-header">
                                <div class="callout callout-info">
                                    <h4>congratulations</h4>
                                    <p><?php echo e(session('added')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(session('updated')): ?>
                            <div class="box-header">
                                <div class="callout callout-info">
                                    <h4>congratulations</h4>
                                    <p><?php echo e(session('updated')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    <div class="box-header">
                        <a href="<?php echo e(url('users/create')); ?>" class="btn btn-info">add user</a>
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>name</th>
                                <th>image</th>
                                <th>email</th>
                                <th>phone</th>
                                <th>business role</th>
                                <th>type</th>
                                <th>create date</th>
                                <th>update date</th>
                                <th>edit</th>
                                <th>delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i =1;?>
                            <?php foreach($users as $user): ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><a href="<?php echo e(url('users/'. $user->id)); ?>"><?php echo e($user->first_name .' '.$user->last_name); ?></a></td>
                                    <td>
                                        <img src="<?php echo e(url('resources/assets/uploads/users')); ?>/<?php echo e($user->image); ?>" class="user-image" alt="user Image" width="25" height="25">
                                    </td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e($user->business_role); ?></td>
                                    <td><?php echo e($user->type); ?></td>
                                    <td><?php echo e($user->created_at); ?></td>
                                    <td><?php echo e($user->updated_at); ?></td>
                                    <td class="form-holder">
                                        <a class="btn btn-primary" href="<?php echo e(url('users/'. $user->id .'/edit')); ?>"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <td class="form-holder">

                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="<?php echo e('#modal-danger-'.$user->id); ?>">
                                            X
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; ?>


                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>

    <?php foreach($users as $user): ?>
        <div class="modal modal-danger fade in" id="<?php echo e('modal-danger-'.$user->id); ?>" style=" padding-right: 17px;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">alert</h4>
                    </div>
                    <div class="modal-body">
                        <p>do you realy want to delete user <strong style="color: #000;"><?php echo e($user->first_name); ?></strong></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                        <?php echo Form::open(['url' => 'users/'.$user->id, 'method' => 'delete']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    <?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>