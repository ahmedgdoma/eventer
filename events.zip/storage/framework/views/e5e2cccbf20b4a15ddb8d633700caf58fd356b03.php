
<?php $__env->startSection('title'); ?>
    event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            <?php echo e($event->title); ?> event
        </h1>

        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">events</a></li>
            <li class="active">profile</li>
        </ol>
    </section>
    <Section class="content">
        <div class="row">
            <div class='col-md-12'>
                <?php if(session('error')): ?>
                    <div class="box-header">
                        <div class="callout callout-danger">
                            <h4>error!</h4>
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(session('deleted')): ?>
                    <div class="box-header">
                        <div class="callout callout-info">
                            <h4>congratulations</h4>
                            <p><?php echo e(session('deleted')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(session('added')): ?>
                    <div class="box-header">
                        <div class="callout callout-info">
                            <h4>congratulations</h4>
                            <p><?php echo e(session('added')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(session('updated')): ?>
                    <div class="box-header">
                        <div class="callout callout-info">
                            <h4>congratulations</h4>
                            <p><?php echo e(session('updated')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                    <?php if(session('material_added')): ?>
                        <div class="box-header">
                            <div class="callout callout-info">
                                <h4>congratulations</h4>
                                <p><?php echo e(session('material_added')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(session('chair_reserved')): ?>
                        <div class="box-header">
                            <div class="callout callout-info">
                                <h4>congratulations</h4>
                                <p><?php echo e(session('chair_reserved')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(session('mails')): ?>
                        <div class="box-header">
                            <div class="callout callout-info">
                                <h4>congratulations</h4>
                                <p><?php echo e(session('mails')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                <table class="table table-bordered table-responsive event-table">
                    <tbody>
                    <tr>
                        <th>title</th>
                        <td><?php echo e($event->title); ?></td>
                    </tr>
                    <tr>
                        <th>image</th>
                        <td><img src="<?php echo e(url('resources/assets/uploads/events\/') . $event->image); ?>" width="200" height="100"></td>
                    </tr>
                    <tr>
                        <th>description</th>
                        <td><?php echo e($event->description); ?></td>
                    </tr>
                    <tr>
                        <th>type</th>
                        <td>
                            <?php echo e($event->type); ?>

                            <?php if($event->type == 'private'): ?>
                                <a href="<?php echo e(url('/sendmails/'.$event->id)); ?>" class="btn btn-info">send emails</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>attendance</th>
                        <td><?php echo e($event->attendance); ?></td>
                    </tr>
                    <tr>
                        <th>location</th>
                        <td><?php echo e($event->location); ?></td>
                    </tr>
                    <tr>
                        <th>code</th>
                        <td><?php echo e($event->code); ?></td>
                    </tr>
                    <tr>
                        <th>attendance list</th>
                        <td><a href="<?php echo e(url('/events/attendance/'.$event->id)); ?>" class="btn btn-primary">view attendance list</a></td>
                    </tr>
                    <tr>
                        <th>edit</th>
                        <td><a href="<?php echo e(url('events/'. $event->id .'/edit')); ?>" class="btn btn-primary">edit</a></td>
                    </tr>
                    <?php if($event->attendance == 'complete'): ?>
                        <tr>
                            <th>event speaker</th>
                            <td><strong>session title</strong>: <span>speaker name</span><br>
                                <?php foreach($event->sessions as $session): ?>
                                    <strong><?php echo e($session->title); ?></strong>: <span><?php echo e($session->speaker->name); ?></span><br>
                                <?php endforeach; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                    <?php else: ?>
                    </tbody>
                </table>
                    <div class="panel panel-default">
                        <div class="panel-heading">Sessions</div>
                        <div class="panel-body">
                            <?php foreach($event->sessions as $session): ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <?php echo e($session->title); ?>

                                    </div>
                                    <div class="panel-body">
                                        <strong>speaker name</strong>: <span><?php echo e($session->speaker['name']); ?></span><br>
                                        <strong>speaker start time</strong>: <span><?php echo e($session->start_time); ?></span><br>
                                        <strong>speaker duration</strong>: <span><?php echo e($session->duration); ?></span><br>
                                    </div>
                                    <div class="panel-footer text-right">
                                        <a href="<?php echo e(url('/sessions/'.$session->id . '/edit')); ?>" class="btn btn-primary">edit session</a>
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="<?php echo e('#modal-danger-'.$session->id); ?>">
                                            Delete session
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="panel-footer"><a href="<?php echo e(url('/addSessionForEvent/'.$event->id)); ?>" class="btn btn-primary">add session</a></div>
                    </div>
                    <?php endif; ?>

                    <div class="panel panel-default">
                        <div class="panel-heading">materials</div>
                        <div class="panel-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading">documents</div>
                                    <div class="panel-body">
                                        <ul>
                                    <?php foreach($event->materials as $material): ?>
                                        <?php if($material->type == 'document'): ?>
                                            <li><a href="<?php echo e(url('download/'.$material->id)); ?>"><?php echo e($material->material_name.'.' .$material->extension); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="panel  panel-default">
                                    <div class="panel-heading">images</div>
                                    <div class="panel-body">
                                    <?php foreach($event->materials as $material): ?>
                                        <?php if($material->type == 'image'): ?>
                                            <img class="img-thumbnail" src="<?php echo e(url('/resources/assets/uploads/materials/'. $material->link)); ?>" width="200" height="200">
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                    </div>
                                </div>

                        </div>
                        <div class="panel-footer"><a href="<?php echo e(url('/addMaterialForEvent/'.$event->id)); ?>" class="btn btn-primary">add material</a></div>
                    </div>
                    <?php if($event->type == 'private'): ?>
                        <div class="panel  panel-default">
                            <div class="panel-heading">chairs</div>
                            <div class="panel-body">
                                <?php if(isset($event->vip_chairs) && $event->vip_chairs > 0): ?>
                                    <?php for($i = 1;$i <= $event->vip_chairs; $i++): ?>
                                        <?php if(in_array($i, $chair_num)): ?>
                                            <a href="<?php echo e(url('/chairs/'. $i)); ?>" class="btn btn-success"><?php echo e($i); ?></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('/chairs/create/'. $i . '/'. $event->id)); ?>" class="btn btn-danger"><?php echo e($i); ?></a>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                <?php endif; ?>
                            </div>
                            <div class="panel-footer">
                                <a href="<?php echo e(url('/addChairs/'. $event->id)); ?>" class="btn btn-info">set number of vip chairs</a>
                            </div>
                        </div>
                <?php endif; ?>

                <!-- /.box -->
            </div>
        </div>
    </Section>


    <?php foreach($event->sessions as $session): ?>
        <div class="modal modal-danger fade in" id="<?php echo e('modal-danger-'.$session->id); ?>" style=" padding-right: 17px;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">alert</h4>
                    </div>
                    <div class="modal-body">
                        <p>do you realy want to delete session <strong style="color: #000;"><?php echo e($session->name); ?></strong></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                        <?php echo Form::open(['url' => 'sessions/'.$session->id, 'method' => 'delete']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    <?php endforeach; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>