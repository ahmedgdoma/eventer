<?php $__env->startSection('title'); ?>
    speaker profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            <?php echo e($speaker->name); ?> Profile
        </h1>

        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">speakers</a></li>
            <li class="active">profile</li>
        </ol>
    </section>
    <Section class="content">
        <div class="row">
            <div class='col-md-6 col-md-offset-3'>
                <!-- Profile Image -->
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <img class="profile-user-img img-responsive img-circle" src="<?php echo e(url('resources\assets\uploads\speakers\\'). $speaker->image); ?>" alt="User profile picture">

                        <h3 class="profile-username text-center"><?php echo e($speaker->name); ?></h3>

                        <p class="text-muted text-center"></p>

                        <ul class="list-group list-group-unbordered">
                            <li class="list-group-item">
                                <b>title</b> <span class="pull-right"><?php echo e($speaker->title); ?></span>
                            </li>
                            <li class="list-group-item">
                                <b>description</b> <span class="text-right"><?php echo e($speaker->description); ?></span>
                            </li>
                        </ul>

                        <a href="<?php echo e(url('speakers/'. $speaker->id . '/edit')); ?>" class="btn btn-primary btn-block"><b>Edit</b></a>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </Section>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>