<?php $__env->startSection("title"); ?>
    events
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <section class="content-header">
        <h1>
            events Table
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a class="active">events</a></li>
        </ol>
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">

                <div class="box">
                    <?php if(session('error')): ?>
                        <div class="box-header">
                            <div class="callout callout-danger">
                                <h4>error!</h4>
                                <p><?php echo e(session('error')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(session('deleted')): ?>
                        <div class="box-header">
                            <div class="callout callout-info">
                                <h4>congratulations</h4>
                                <p><?php echo e(session('deleted')); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                        <?php if(session('added')): ?>
                            <div class="box-header">
                                <div class="callout callout-info">
                                    <h4>congratulations</h4>
                                    <p><?php echo e(session('added')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(session('updated')): ?>
                            <div class="box-header">
                                <div class="callout callout-info">
                                    <h4>congratulations</h4>
                                    <p><?php echo e(session('updated')); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    <div class="box-header">
                        <a href="<?php echo e(url('events/create')); ?>" class="btn btn-info">add event</a>
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>title</th>
                                <th>image</th>
                                <th>description</th>
                                <th>type</th>
                                <th>attendance</th>
                                <th>location</th>
                                <th>code</th>
                                <th>create date</th>
                                <th>update date</th>
                                <th>edit</th>
                                <th>delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i =1;?>
                            <?php foreach($events as $event): ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><a href="<?php echo e(url('events/'. $event->id)); ?>"><?php echo e($event->title); ?></a></td>
                                    <td>
                                        <img src="<?php echo e(url('resources/assets/uploads/events')); ?>/<?php echo e($event->image); ?>" class="event-image" alt="event Image" width="25" height="25">
                                    </td>
                                    <td><?php echo e($event->description); ?></td>
                                    <td><?php echo e($event->type); ?></td>
                                    <td><?php echo e($event->attendance); ?></td>
                                    <td><?php echo e($event->location); ?></td>
                                    <td><?php echo e($event->code); ?></td>
                                    <td><?php echo e($event->created_at); ?></td>
                                    <td><?php echo e($event->updated_at); ?></td>
                                    <td class="form-holder">
                                        <a class="btn btn-primary" href="<?php echo e(url('events/'. $event->id .'/edit')); ?>"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <td class="form-holder">

                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="<?php echo e('#modal-danger-'.$event->id); ?>">
                                            X
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; ?>


                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>

    <?php foreach($events as $event): ?>
        <div class="modal modal-danger fade in" id="<?php echo e('modal-danger-'.$event->id); ?>" style=" padding-right: 17px;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">alert</h4>
                    </div>
                    <div class="modal-body">
                        <p>do you realy want to delete event <strong style="color: #000;"><?php echo e($event->title); ?></strong></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                        <?php echo Form::open(['url' => 'events/'.$event->id, 'method' => 'delete']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    <?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>