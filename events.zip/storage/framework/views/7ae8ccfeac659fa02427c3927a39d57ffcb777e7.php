
<?php $__env->startSection("title"); ?>
    send emails
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <section class="content-header">
        <h1>
            send email for vip users
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <?php echo Form::open(['url'=>'/sendtousers']); ?>

                    <div class="row">
                        <?php foreach($users as $user): ?>
                            <div class="form-group col-md-6">
                                <?php echo Form::checkbox('users[]', $user->email, false, ['id'=>$user->id]); ?>

                                <?php echo Form::label($user->id, $user->first_name. ' '.$user->last_name.'('.$user->email.')'); ?>

                            </div>
                        <?php endforeach; ?>
                        <div class="col-md-6">
                            <?php echo Form::label('event code'); ?>

                            <input name="code" value="<?php echo e($event->code); ?>" class="form-control" disabled>
                        </div>
                            <div class="col-md-6">
                                <?php echo Form::label('event title'); ?>

                                <input name="title" value="<?php echo e($event->title); ?>" class="form-control" disabled>
                                <input name="event_id" value="<?php echo e($event->id); ?>" class="form-control" type="hidden">
                            </div>
                            <div class="col-md-12">
                                <?php echo Form::label('email message'); ?>

                                <?php echo Form::textarea('message', null, ['class'=>'form-control']); ?>

                            </div>
                    </div>
                    <div class="box-footer">
                        <?php echo Form::submit('send emails', ['class' => 'btn btn-primary']);; ?>

                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>