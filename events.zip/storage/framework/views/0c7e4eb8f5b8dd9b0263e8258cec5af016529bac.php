<?php $__env->startSection("title"); ?>
    add event
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <section class="content-header">
        <h1>
            add event
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a class="active">events</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="box">
                    <div class="box-body">
                        <?php echo e(Form::open(['action'=>'eventController@store', 'files'=>'true '])); ?>

                        <div id="event-form">
                            <?php echo e(Form::label('title')); ?>

                            <?php if(count($errors->first('title')) > 0): ?>
                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                            <?php endif; ?>
                            <?php echo e(Form::text('title', null, ['class'=>'form-control', 'placeholder'=>'event title'])); ?>


                            <?php echo e(Form::label('description')); ?>

                            <?php if(count($errors->first('description')) > 0): ?>
                                <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                            <?php endif; ?>
                            <?php echo e(Form::textarea('description', null, ['class'=>'form-control'])); ?>


                            <?php echo e(Form::label('code')); ?>

                            <?php if(count($errors->first('code')) > 0): ?>
                                <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                            <?php endif; ?>
                            <?php echo e(Form::text('code', null, ['class'=>'form-control', 'placeholder'=>'event code'])); ?>


                            <?php echo e(Form::label('type')); ?>

                            <?php if(count($errors->first('type')) > 0): ?>
                                <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                            <?php endif; ?>
                            <?php echo e(Form::select('type',['private'=>'private','public'=>'public'] ,null, ['class'=>'form-control ', 'placeholder'=>'type'])); ?>



                            <?php echo e(Form::label('attendance')); ?>

                            <?php if(count($errors->first('attendance')) > 0): ?>
                                <span class="text-danger"><?php echo e($errors->first('attendance')); ?></span>
                            <?php endif; ?>
                            <?php echo e(Form::select('attendance',['complete'=>'complete','sessions'=>'sessions'] ,null, ['class'=>'type form-control', 'placeholder'=>'attendance'])); ?>


                            <?php echo e(Form::label('image')); ?>

                            <?php echo e(Form::file('image')); ?>

                            <div class="box-footer text-center">
                                <span class="btn btn-primary change" data-toggle="session-form">next</span>
                            </div>
                        </div>
                        <div  id="session-form">
                            <div class="session-holder">
                                <?php echo e(Form::label('session title')); ?>

                                <?php echo e(Form::text('session_title[]', null, ['class'=>'form-control', 'placeholder'=>'session title'])); ?>


                                <?php echo e(Form::label('session start time')); ?>

                                <?php echo e(Form::time('session_time[]', \Carbon\Carbon::now(), ['class'=>'form-control', 'placeholder'=>'session start time'])); ?>


                                <?php echo e(Form::label('session duration in hours')); ?>

                                <?php echo e(Form::number('session_duration[]', null, ['class'=>'form-control', 'placeholder'=>'session duration in hours'])); ?>


                                <?php echo e(Form::label('session speaker')); ?>

                                <?php echo e(Form::select('session_speaker[]',$speakers ,null, ['class'=>'form-control', 'placeholder'=>'session speaker'])); ?>



                            </div>
                            <div class="box-footer">
                                <span class="btn btn-info add" >add another session</span>
                            </div>

                            <div class="box-footer text-center">
                                <span class="btn btn-primary change" data-toggle="event-form">back</span>
                                <?php echo Form::submit('submit', ['class' => 'btn btn-primary']);; ?>

                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('.change').on('click', function(){
            $('#' + $(this).data('toggle')).show().siblings('div').hide();
        });
        $('.type').on('change', function(){
            if ($(this).val() == "sessions"){
                $('.add').show();
                $('.add').on('click', function (){
                    $(this).parent().before("<div class='session-holder'>"+$('.session-holder').html()+'</div>');
                    $('.remove').show();
                });
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>