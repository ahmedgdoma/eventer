<?php $__env->startSection("title"); ?>
    speakers
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <section class="content-header">
        <h1>
            speakers Table
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a class="active">speakers</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">

                <div class="box">
                    <div class="box-header">
                        <a href="<?php echo e(url('speakers/create')); ?>" class="btn btn-info">add speaker</a>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>name</th>
                                <th>image</th>
                                <th>title</th>
                                <th>description</th>
                                <th>create date</th>
                                <th>update date</th>
                                <th>edit</th>
                                <th>delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i =1;?>
                            <?php foreach($speakers as $speaker): ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><a href="<?php echo e(url('speakers/'. $speaker->id)); ?>"><?php echo e($speaker->name); ?></a></td>
                                    <td>
                                        <img src="<?php echo e(url('resources\assets\uplaods\speakers'). $speaker->image); ?>" class="user-image" alt="speaker Image" width="25" height="25">
                                    </td>
                                    <td><?php echo e($speaker->title); ?></td>
                                    <td><?php echo e($speaker->description); ?></td>
                                    <td><?php echo e($speaker->created_at); ?></td>
                                    <td><?php echo e($speaker->updated_at); ?></td>
                                    <td class="form-holder">
                                        <a class="btn btn-primary" href="<?php echo e(url('speakers/'. $speaker->id .'/edit')); ?>"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <td class="form-holder">

                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="<?php echo e('#modal-danger-'.$speaker->id); ?>">
                                            X
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; ?>


                            </tbody>

                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>

    <?php foreach($speakers as $speaker): ?>
        <div class="modal modal-danger fade in" id="<?php echo e('modal-danger-'.$speaker->id); ?>" style=" padding-right: 17px;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span></button>
                        <h4 class="modal-title">alert</h4>
                    </div>
                    <div class="modal-body">
                        <p>do you realy want to delete speaker <strong style="color: #000;"><?php echo e($speaker->name); ?></strong></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                        <?php echo Form::open(['url' => 'speakers/'.$speaker->id, 'method' => 'delete']); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    <?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>